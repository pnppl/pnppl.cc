pnppl

# What the hell is "pnppl"?

It's me! pnppl is my hacker name. My screen name. My handle. My nom de plume. My... nom de guerre?

# Why?

I can type it fast and it's usually not taken.

# Okay but like... what does it mean? Where did it come from?

It means nothing. It means me. The origin is not very interesting; you can probably figure it out.

Alternatively, a friend of mine interprets it as P=NP.pl. This is much cooler and hackerier and I encourage you to read it that way, even though P≠NP and I've never written a line of Perl in my life.

# How is it pronounced?

I say it "pee-nipple", but I'm also four years old. Please feel free to invent a more dignified pronunciation. Maybe make the `p`s silent.

# Are you a swinger?

Not yet, but my inbox is always open.

#meta
